#ifndef JSONREADER_H_
#define JSONREADER_H_

int parse_file(char *fileName);

#endif /* JSONREADER_H_ */
