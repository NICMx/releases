#ifndef _JOOL_USR_TARGET_JOOLD_H
#define _JOOL_USR_TARGET_JOOLD_H

int joold_advertise(void);
int joold_test(void);

#endif
