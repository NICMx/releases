#include "nat64/common/config.h"

int config_parse(struct full_config *config, void *payload, size_t payload_len)
{
	return -EINVAL;
}
