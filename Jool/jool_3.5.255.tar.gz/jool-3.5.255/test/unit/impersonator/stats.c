#include "nat64/mod/common/stats.h"

void inc_stats(struct packet *pkt, int field)
{
	/* No code. */
}

void inc_stats_skb6(struct sk_buff *skb, int field)
{
	/* No code. */
}

void inc_stats_skb4(struct sk_buff *skb, int field)
{
	/* No code. */
}
