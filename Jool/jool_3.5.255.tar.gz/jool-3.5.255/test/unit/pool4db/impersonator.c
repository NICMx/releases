#include "nat64/mod/stateful/pool4/rfc6056.h"
#include "nat64/unit/unit_test.h"

int rfc6056_f(const struct tuple *tuple6, __u8 fields, unsigned int *result)
{
	return broken_unit_call(__func__);
}
