#include "nat64/common/xlat.h"

const char *xlat_get_name(void)
{
	return "Graybox";
}
