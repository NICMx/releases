#ifndef GRAYBOX_MOD_NLHANDLER_H
#define GRAYBOX_MOD_NLHANDLER_H

int nlhandler_setup(void);
void nlhandler_teardown(void);

#endif
