#!/bin/bash

modprobe -r jool
modprobe -r jool_siit
