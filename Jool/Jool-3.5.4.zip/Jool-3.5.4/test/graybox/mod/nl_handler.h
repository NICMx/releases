#ifndef GRAYBOX_MOD_NLHANDLER_H
#define GRAYBOX_MOD_NLHANDLER_H

int nlhandler_init(void);
void nlhandler_destroy(void);

#endif
