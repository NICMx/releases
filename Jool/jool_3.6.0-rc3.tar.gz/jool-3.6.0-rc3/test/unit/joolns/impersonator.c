#include "mod/common/nl/global.h"

int global_update(struct global_config *cfg, bool force,
		struct global_value *request, size_t request_size)
{
	return -EINVAL;
}
