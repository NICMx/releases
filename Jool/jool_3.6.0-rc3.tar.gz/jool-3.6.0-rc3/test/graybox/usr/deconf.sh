rm -f Makefile
rm -f Makefile.in
rm -f aclocal.m4
rm -f compile
rm -f config.log
rm -f config.status
rm -f configure
rm -f depcomp
rm -f install-sh
rm -f missing
rm -rf autom4te.cache

