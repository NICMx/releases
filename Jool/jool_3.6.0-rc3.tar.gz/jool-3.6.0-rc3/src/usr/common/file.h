#ifndef _JOOL_USR_FILE_H
#define _JOOL_USR_FILE_H

int file_to_string(char *file_name, char **result);

#endif
