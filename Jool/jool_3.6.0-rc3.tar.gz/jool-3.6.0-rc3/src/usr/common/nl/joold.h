#ifndef _JOOL_USR_TARGET_JOOLD_H
#define _JOOL_USR_TARGET_JOOLD_H

int joold_advertise(char *iname);
int joold_test(char *iname);

#endif
