#ifndef SRC_USERSPACE_CLIENT_ARGP_FILE_H_
#define SRC_USERSPACE_CLIENT_ARGP_FILE_H_

int handle_file_update(char *iname, int argc, char **argv, void *arg);
void autocomplete_file_update(void *args);

#endif /* SRC_USERSPACE_CLIENT_ARGP_FILE_H_ */
