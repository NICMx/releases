#ifndef SRC_USR_COMMON_ARGP_STATS_H_
#define SRC_USR_COMMON_ARGP_STATS_H_

int handle_stats_display(char *iname, int argc, char **argv, void *arg);
void autocomplete_stats_display(void *args);

#endif /* SRC_USR_COMMON_ARGP_STATS_H_ */
