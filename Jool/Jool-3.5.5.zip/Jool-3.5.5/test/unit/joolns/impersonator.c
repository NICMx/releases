#include "nat64/mod/common/nl/nl_handler.h"
#include "nat64/mod/common/nl/global.h"

int config_parse(struct full_config *config, void *payload, size_t payload_len)
{
	return -EINVAL;
}
