#ifndef __NL_LOGTIME_H__
#define __NL_LOGTIME_H__

#include <net/genetlink.h>

int handle_logtime_config(struct genl_info *info);

#endif
