#ifndef _JOOL_USR_SESSION_H
#define _JOOL_USR_SESSION_H

#include "nat64/usr/types.h"

int session_display(display_flags flags);
int session_count(display_flags flags);


#endif /* _JOOL_USR_SESSION_H */
