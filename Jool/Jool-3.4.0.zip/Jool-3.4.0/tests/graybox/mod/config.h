#ifndef FRAGS_MOD_CONFIG_H
#define FRAGS_MOD_CONFIG_H

int config_init(void);
void config_destroy(void);

#endif /* FRAGS_MOD_CONFIG_H */
