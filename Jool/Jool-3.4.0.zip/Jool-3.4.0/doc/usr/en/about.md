---
language: en
layout: default
category: About
title: About
---

# About

Jool is an Open Source [IPv4/IPv6 Translator](intro-xlat.html), funded by <a href="http://nicmexico.mx/" target="_blank">NIC Mexico</a> and co-developed with <a href="http://www.itesm.mx/" target="_blank">ITESM</a>.

Both code and documentation are relased under the GPLv3 license.

