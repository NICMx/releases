#include "nat64/common/xlat.h"

bool xlat_is_siit(void)
{
	return false;
}

const char *xlat_get_name(void)
{
	return "NAT64 Jool";
}
