#ifdef BENCHMARK
#ifndef _JOOL_USR_LOG_TIME_H
#define _JOOL_USR_LOG_TIME_H
/*
 * log_time.h
 *
 *  Created on: Oct 3, 2014
 *      Author: dhernandez
 */

#include <time.h>

int logtime_display();

#endif /* _JOOL_USR_LOG_TIME_H */
#endif /* BENCHMARK */
