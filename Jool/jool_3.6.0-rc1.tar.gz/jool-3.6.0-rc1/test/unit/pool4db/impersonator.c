#include "mod/nat64/pool4/rfc6056.h"
#include "framework/unit_test.h"

int rfc6056_f(const struct tuple *tuple6, __u8 fields, unsigned int *result)
{
	return broken_unit_call(__func__);
}
