#ifndef SRC_MOD_COMMON_DEFRAG_H_
#define SRC_MOD_COMMON_DEFRAG_H_

#include <net/net_namespace.h>

void defrag_enable(struct net *ns);

#endif /* SRC_MOD_COMMON_DEFRAG_H_ */
