#include "mod/common/defrag.h"

void defrag_enable(struct net *ns)
{
	/* SIIT does not want to enable defrag. */
}
