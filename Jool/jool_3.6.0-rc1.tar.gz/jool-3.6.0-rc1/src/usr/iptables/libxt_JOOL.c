#include "common/config.h"

#define IPTABLES_MODULE_NAME IPTABLES_NAT64_MODULE_NAME
#include "common.c"
