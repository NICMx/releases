#ifndef SRC_USR_COMMON_ARGP_STATS_H_
#define SRC_USR_COMMON_ARGP_STATS_H_

int handle_stats_display(char *iname, int argc, char **argv, void *arg);
void print_stats_display_opts(char *prefix);

#endif /* SRC_USR_COMMON_ARGP_STATS_H_ */
