#ifndef SRC_USERSPACE_CLIENT_ARGP_FILE_H_
#define SRC_USERSPACE_CLIENT_ARGP_FILE_H_

int handle_file_update(char *iname, int argc, char **argv, void *arg);
void print_file_update_opts(char *prefix);

#endif /* SRC_USERSPACE_CLIENT_ARGP_FILE_H_ */
