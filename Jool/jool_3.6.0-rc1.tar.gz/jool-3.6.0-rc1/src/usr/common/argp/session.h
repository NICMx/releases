#ifndef SRC_USERSPACE_CLIENT_ARGP_SESSION_H_
#define SRC_USERSPACE_CLIENT_ARGP_SESSION_H_

int handle_session_display(char *iname, int argc, char **argv, void *arg);

void print_session_display_opts(char *prefix);

#endif /* SRC_USERSPACE_CLIENT_ARGP_SESSION_H_ */
