#include "common/xlat.h"

int xlat_type(void)
{
	return XT_SIIT;
}

const char *xlat_get_name(void)
{
	return "SIIT Jool";
}
