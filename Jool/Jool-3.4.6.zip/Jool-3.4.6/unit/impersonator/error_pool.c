#include "nat64/mod/common/error_pool.h"

int error_pool_add_message(char *msg)
{
	return 0;
}
