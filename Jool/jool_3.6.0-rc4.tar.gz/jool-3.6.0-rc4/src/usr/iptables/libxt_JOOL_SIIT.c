#include "common/config.h"

#define IPTABLES_MODULE_NAME IPTABLES_SIIT_MODULE_NAME
#include "common.c"
