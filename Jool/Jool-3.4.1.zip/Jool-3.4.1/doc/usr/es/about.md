---
language: es
layout: default
category: About
title: Acerca de...
---

# Acerca de...


Jool es un [Traductor IPv4/IPv6](intro-xlat.html) de código abierto. Nació como un Stateful NAT64 pero ha sido ampliado para soportar también SIIT.

Jool es financiado y desarrollado por [NIC Mexico](http://nicmexico.mx/) y en colaboración con el [ITESM](http://www.itesm.mx/).

El código y la documentación han sido liberados bajo la licencia GPLv3.

