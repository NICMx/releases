#include "common/xlat.h"

const char *xlat_get_name(void)
{
	return "Graybox";
}
