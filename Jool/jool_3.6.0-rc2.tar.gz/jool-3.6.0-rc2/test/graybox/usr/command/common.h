#ifndef _GRAYBOX_USR_CMD_COMMON_H
#define _GRAYBOX_USR_CMD_COMMON_H

#include <stddef.h>

int load_pkt(char *filename, unsigned char **result, size_t *result_len);

#endif
