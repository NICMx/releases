#ifndef TEST_UNIT_FRAMEWORK_SEND_PACKET_H_
#define TEST_UNIT_FRAMEWORK_SEND_PACKET_H_

#include "mod/common/send_packet.h"

extern struct sk_buff *skb_out;

#endif /* TEST_UNIT_FRAMEWORK_SEND_PACKET_H_ */
