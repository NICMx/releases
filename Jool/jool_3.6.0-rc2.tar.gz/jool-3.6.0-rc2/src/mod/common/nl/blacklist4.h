#ifndef __NL_POOL_H__
#define __NL_POOL_H__

#include <net/genetlink.h>
#include "mod/common/xlator.h"

int handle_blacklist4_config(struct xlator *jool, struct genl_info *info);

#endif
