#ifndef JSONREADER_H_
#define JSONREADER_H_

#include <stdbool.h>

int parse_file(char *fileName, bool force);

#endif /* JSONREADER_H_ */
