#include "nat64/common/xlat.h"

bool xlat_is_siit(void)
{
	return true;
}

const char *xlat_get_name(void)
{
	return "SIIT Jool";
}
